package com.example.periodic_site_checker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
