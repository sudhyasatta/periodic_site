import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:http/http.dart' as http;
import 'package:workmanager/workmanager.dart';

import '../model/url_model.dart';

class AddUrlModelShhetContent extends StatefulWidget {
  const AddUrlModelShhetContent({
    Key? key,
  }) : super(key: key);

  @override
  State<AddUrlModelShhetContent> createState() =>
      _AddUrlModelShhetContentState();
}

class _AddUrlModelShhetContentState extends State<AddUrlModelShhetContent> {
  TextEditingController controller = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  
  Future addUrlToHive(String url) async {
    String status;
    try {
      final response = await http.head(Uri.parse('https://$url'));
      if (response.statusCode == 200) {
        log("UP");
        status = "is UP";
      } else {
        status = "is Down";
        log("Down");
      }
    } catch (e) {
      status = "Not Found";
      log(e.toString());
    }
    UrlModel model =
        UrlModel(url: url, status: status, lastUpdated: DateTime.now());

    final openBox = Hive.box<UrlModel>("_urlHiveModel");
    await openBox.add(model);
  }

  static String? emptyValidator(value) {
    if (value == null) {
      return '\u2a2f This is mendatory field';
    } else if (value!.isEmpty) {
      return '\u2a2f This is mendatory field';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
        top: 16,
        left: 16,
        right: 16,
      ),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                height: 3.5,
                width: MediaQuery.of(context).size.width / 3,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.black54),
              ),
            ),
            const SizedBox(height: 30),
            Text(
              'Add New URL !',
              style: Theme.of(context).textTheme.headline6,
            ),
            const SizedBox(height: 10.0),
            Text(
              "Enter any Site Name to check its Wheather its UP or Down Periodically!",
              style: Theme.of(context)
                  .textTheme
                  .bodyText2!
                  .copyWith(color: Colors.grey[700], fontSize: 14),
            ),
            const SizedBox(height: 20.0),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: Center(
                child: TextFormField(
                  controller: controller,
                  validator: emptyValidator,
                  style: Theme.of(context).textTheme.bodyLarge,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  decoration: InputDecoration(
                      prefixText: "http:// ",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                        borderSide: const BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                        ),
                      ),
                      filled: true,
                      isDense: false,
                      contentPadding: const EdgeInsets.only(
                          left: 11.0, top: 8.0, bottom: 8.0),
                      hintText: "Enter Url",
                      labelText: "Enter Url",
                      fillColor: Colors.black12),
                ),
              ),
            ),
            const SizedBox(
              height: 30,
            ),
            SizedBox(
              width: double.infinity,
              height: 45,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    padding: const EdgeInsets.all(5),
                    side: const BorderSide(width: 1.4, color: Colors.blueGrey),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10))),
                child: Text("ADD URL".toUpperCase(),
                    style: Theme.of(context)
                        .textTheme
                        .headline6!
                        .copyWith(shadows: <Shadow>[
                      const Shadow(
                        offset: Offset(0.5, 0.5),
                        blurRadius: 1.0,
                        color: Colors.white,
                      ),
                    ], color: Colors.black87, fontSize: 15, letterSpacing: 2)),
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    addUrlToHive(controller.text).then((value) {
                      Navigator.pop(context);
                    });
                  }
                },
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
