import 'dart:io';

import 'package:periodic_site_checker/widgets/add_url_model_sheet_content.dart';
import 'package:flutter/material.dart';
import 'package:hive_flutter/adapters.dart';
import 'package:path_provider/path_provider.dart' as path_provider;
import 'package:timeago/timeago.dart' as timeago;
import 'package:workmanager/workmanager.dart';
import 'package:http/http.dart' as http;

import 'model/url_model.dart';

void callbackDispatcher() {
  Workmanager().executeTask((taskName, inputData) async {
    final openBox = Hive.box<UrlModel>("_urlHiveModel");
    int length = openBox.length;

    if (length > 0) {
      List<UrlModel> model = [];
      for (int i = 0; i < length; i++) {
        model.add(openBox.getAt(i)!);
      }

      model.forEach((e) async {
        String status = "";
        try {
          final response = await http.head(Uri.parse('https://${e.url}'));

          if (response.statusCode == 200) {
            status = "is UP";
          } else {
            status = "is Down";
          }
        } catch (e) {
          status = "Not Found";
        }
        UrlModel model =
            UrlModel(url: e.url, status: status, lastUpdated: DateTime.now());

        final openBox = Hive.box<UrlModel>("_urlHiveModel");
        await openBox.put(e.key, model);
      });

      return Future.value(true);
    } else {
      return Future.value(true);
    }
  });
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final appDirectory = await path_provider.getApplicationDocumentsDirectory();
  Hive.init(appDirectory.path);
  Hive.registerAdapter(UrlModelAdapter());
  await Hive.openBox<UrlModel>("_urlHiveModel");
  Workmanager().initialize(callbackDispatcher);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'Periodic Site Checker'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  registerWorkManager() {
    Workmanager().registerPeriodicTask(
      "uniqueName",
      "UpdateSiteStatus",
      frequency: const Duration(minutes: 15),
      constraints: Constraints(networkType: NetworkType.connected),
    );
  }

  @override
  void initState() {
    registerWorkManager();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: Text(widget.title),
      ),
      body: ValueListenableBuilder(
        builder: (BuildContext context, Box box, Widget? child) {
          Map<dynamic, dynamic> raw = box.toMap();
          List<UrlModel> urlList = raw.values.toList().cast();
          return urlList.isEmpty
              ? Center(
                  child: SizedBox(
                    height: 300,
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(
                            Icons.link_off_rounded,
                            size: 80,
                            color: Colors.blueGrey,
                          ),
                          const SizedBox(height: 50),
                          Text("Please Add New Url !",
                              style: Theme.of(context).textTheme.bodyLarge),
                        ],
                      ),
                    ),
                  ),
                )
              : ListView.builder(
                  itemCount: urlList.length,
                  shrinkWrap: true,
                  itemBuilder: (BuildContext context, int index) {
                    return Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: Card(
                        elevation: 4,
                        clipBehavior: Clip.antiAlias,
                        child: ListTile(
                          contentPadding: EdgeInsets.zero,
                          leading: Container(
                              color: urlList[index].status == "is UP"
                                  ? Colors.green
                                  : urlList[index].status == "is Down"
                                      ? Colors.deepOrange
                                      : Colors.red,
                              child: AspectRatio(
                                  aspectRatio: 1,
                                  child: Icon(
                                    urlList[index].status == "is UP"
                                        ? Icons.arrow_circle_up_outlined
                                        : urlList[index].status == "is Down"
                                            ? Icons.arrow_circle_down_outlined
                                            : Icons.close,
                                    color: Colors.white,
                                  ))),
                          title: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("https:// ${urlList[index].url}",
                                  style:
                                      Theme.of(context).textTheme.bodyMedium),
                              const SizedBox(height: 8),
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: StreamBuilder(
                                        stream: Stream.periodic(
                                            const Duration(seconds: 1),
                                            (i) => i),
                                        builder: (BuildContext context,
                                            AsyncSnapshot<int> snapshot) {
                                          return Text(
                                            timeago.format(
                                                urlList[index].lastUpdated),
                                            style: Theme.of(context)
                                                .textTheme
                                                .bodySmall,
                                          );
                                        }),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 1, horizontal: 10),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(4),
                                        color: urlList[index].status == "is UP"
                                            ? Colors.green
                                            : urlList[index].status == "is Down"
                                                ? Colors.deepOrange
                                                : Colors.red),
                                    child: Text(
                                      "Site ${urlList[index].status}"
                                          .toUpperCase(),
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodySmall!
                                          .copyWith(
                                              letterSpacing: 1,
                                              fontWeight: FontWeight.bold,
                                              shadows: [
                                                const Shadow(
                                                    color: Colors.black,
                                                    offset: Offset(0.5, 0.5),
                                                    blurRadius: 1)
                                              ],
                                              color: Colors.white),
                                    ),
                                  ),
                                  const SizedBox(width: 10)
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                );
        },
        valueListenable: Hive.box<UrlModel>("_urlHiveModel").listenable(),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          AddUrlSheet.openSheet(context: context);
        },
        tooltip: 'ADD URL',
        child: const Icon(Icons.add),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}

class AddUrlSheet {
  static openSheet({required BuildContext context}) {
    return showModalBottomSheet(
            isDismissible: true,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(15.0),
                  topRight: Radius.circular(15.0)),
            ),
            backgroundColor: Colors.white,
            isScrollControlled: true,
            enableDrag: true,
            context: context,
            builder: (context) => const AddUrlModelShhetContent())
        .then((login) async {
      if (login != null && login == true) {
      } else if (login != null && login == false) {
      } else {}
    });
  }
}
