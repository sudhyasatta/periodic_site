import 'dart:convert';
import 'package:hive/hive.dart';
part 'url_model.g.dart';


UrlModel urlModelFromJson(String str) => UrlModel.fromJson(json.decode(str));
String urlModelToJson(UrlModel data) => json.encode(data.toJson());

@HiveType(typeId: 1)
class UrlModel extends HiveObject {
  UrlModel({
    required this.url,
    required this.lastUpdated,
    required this.status,
  });
  @HiveField(0)
  final String url;
  @HiveField(1)
  final DateTime lastUpdated;
  @HiveField(2)
  final String status;

  factory UrlModel.fromJson(Map<String, dynamic> json) => UrlModel(
        url: json["url"],
        lastUpdated: json["lastUpdated"],
        status: json["status"],
      );

  Map<String, dynamic> toJson() => {
        "url": url,
        "lastUpdated": lastUpdated,
        "status": status,
      };
}
